"idle" files are baseline and "det" files are attempts to make engine detonate, all while parked - reving with brakes and in gear on automatic transmission.

magenta line cylinder #1 ignition trigger signal
yellow line ion sitnal from coil #1
blue line knock signal produced by CDM